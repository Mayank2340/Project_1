import { useEffect, useState } from "react";
import { DateTime } from "luxon";
import copy from "clipboard-copy";
import Swal from 'sweetalert2'
import "./App.css";

function App() {
  const [userInputTime, setUserInputTime] = useState("");
  const [utcTime, setUtcTime] = useState(new Date());
  const [istTime, setIstTime] = useState("");

  const handleConversion = () => {
    const utcTime = DateTime.fromISO(userInputTime, { zone: "utc" });
    const istTime = utcTime.setZone("Asia/Kolkata");
    setIstTime(istTime);
  };

  // Universal Time Coordinated

  useEffect(() => {
    // Function to update the UTC time
    const updateUtcTime = () => {
      setUtcTime(new Date());
    };

    // Set up an interval to update the time every second
    const intervalId = setInterval(updateUtcTime, 1000);

    // Clear the interval when the component unmounts
    return () => {
      clearInterval(intervalId);
    };
  }, []);

  function getGMTName(utcTime) {
    const date = new Date(utcTime);
    const offsetMinutes = date.getTimezoneOffset();

    // Convert the offset to hours and minutes
    const offsetHours = Math.abs(Math.floor(offsetMinutes / 60));
    const offsetMinutesRemainder = Math.abs(offsetMinutes % 60);

    // Determine the sign of the offset
    const offsetSign = offsetMinutes > 0 ? "-" : "+";

    // Create the GMT name string
    const gmtName = `GMT${offsetSign}${String(offsetHours).padStart(
      2,
      "0"
    )}:${String(offsetMinutesRemainder).padStart(2, "0")}`;

    return gmtName;
  }

  const gmtName = getGMTName(utcTime);
  const weekdayNames = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  // const utcMonth = utcTime.getUTCMonth() + 1;
  const todyDate = utcTime.getDate();
  const utcHours = utcTime.getUTCHours();
  const utcMinutes = utcTime.getUTCMinutes();
  const utcSeconds = utcTime.getUTCSeconds();
  const period = utcHours >= 12 ? "pm" : "am";
  const yearName = utcTime.getUTCFullYear();
  const monthNumber = utcTime.getUTCMonth();
  const weekdayNumber = utcTime.getUTCDay();

  const monthname = monthNames[monthNumber];
  const todayDay = weekdayNames[weekdayNumber];

  // Get the leading zero if needed
  const month = (monthNumber + 1).toString().padStart(2, "0");
  const day = todyDate.toString().padStart(2, "0");
  const hours = utcHours.toString().padStart(2, "0");
  const minutes = utcMinutes.toString().padStart(2, "0");
  const second = utcSeconds.toString().padStart(2, "0");

  const utcTimeString = `${yearName}-${month}-${day}T${hours}:${minutes}:${second}`;

  const handleCopy = () => {
    copy(utcTimeString);
    Swal.fire({
      position: 'top',
      icon: 'success',
      title: 'Text copied to clipboard !!',
      showConfirmButton: false,
      timer: 1500
    })
    
  };

  return (
    <>
      <div className="container p-2 bg-secondary  bg-gradient mt-2 rounded text-white shadow-sm border border-dark">
        <h2 className="lh-1">Universal Time Coordinated(UTC)</h2>
        {/* <button className="p-3 ms-4 text-white shadow border bg-primary bg-gradient  py-2 rounded"> */}
        {monthname},{day} {yearName} {period}
        {/* </button> */}
        <hr className="bg-white p-2" />
        {/* <p className="bg-primary bg-gradient p-2 rounded">
          {utcTime.toUTCString()}
        </p> */}
        <div className="p-1">
          <button className=" m-2 ms-5 text-white shadow border bg-primary bg-gradient  py-2 px-3 rounded">
            {utcTimeString}
          </button>
          <button className="btn btn-primary" onClick={handleCopy}>
            Copy
          {/* <i className="fa fa-clone" aria-hidden="true"></i> */}
          </button>
        </div>
        <div className="row">
          <div className="d-flex">
            <div className="p-3 ms-4 text-white shadow border bg-primary bg-gradient  py-2 rounded">
              {gmtName}
            </div>
            <div className="p-3 ms-4 text-white shadow border bg-primary bg-gradient  py-2 rounded">
              {todayDay} {todyDate},{monthname}
            </div>
          </div>
        </div>
      </div>
      {/* {utcTimeString}<br/> */}
      <div className="container p-2 bg-secondary  bg-gradient mt-2 rounded text-white shadow border border-dark">
        <h2 className="ms-2">UTC to IST Converter</h2>
        <hr className="bg-white p-2" />
        <div className="col-auto row ms-2">
          <label className="lh-1">
            Enter UTC (Universal Time Coordinated) Time:
          </label>
          <br />
          <input
            // type="datetime-local"
            type="text"
            className="form-control w-auto mx-1"
            id="utcTime"
            value={userInputTime}
            onChange={(e) => setUserInputTime(e.target.value)}
            placeholder="e.g., 2023-10-08T12:00:00"
          />
          <div className="col-auto">
            <button
              type="submit"
              className="btn btn-outline-warning text-dark mx-1"
              onClick={handleConversion}
            >
              Convert to IST
            </button>
          </div>
        </div>
        <hr />
        {istTime ? (
          <div className="container p-2 mt-2 rounded text-white ">
            <div className="time">
              <p className="lh-1">Converted India Standard Time (IST):</p>
              <p className="bg-primary bg-gradient p-2 rounded">
                {istTime.toLocaleString(DateTime.DATETIME_FULL_WITH_SECONDS)}
              </p>
            </div>
          </div>
        ) : (
          <>
            <p className="bg-primary bg-gradient p-2 rounded">
              You have no convert time
            </p>
          </>
        )}
        <br />
      </div>
    </>
  );
}

export default App;
